// student 1 - Omer Goldstein - 205906258
// student 2 - Shlomi Fridman - 318187002

package your_code;

import java.io.IOException;
import java.util.List;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.joml.Vector4i;

import app_interface.DisplayTypeEnum;
import app_interface.ExerciseEnum;
import app_interface.IntBufferWrapper;
import app_interface.OBJLoader;
import app_interface.TriangleFace;

public class ObjectModel {
	WorldModel worldModel;

	private int imageWidth;
	private int imageHeight;

	private List<VertexData> verticesData;
	private List<TriangleFace> faces;
	private IntBufferWrapper textureImageIntBufferWrapper;

	private Matrix4f modelM = new Matrix4f();
	private Matrix4f lookatM = new Matrix4f();
	private Matrix4f projectionM = new Matrix4f();
	private Matrix4f viewportM = new Matrix4f();
	private Vector3f boundingBoxDimensions;
	private Vector3f boundingBoxCenter;

	private Vector3f lightPositionEyeCoordinates = new Vector3f();

	public static ExerciseEnum exercise = ExerciseEnum.EX_9___Lighting;

	public ObjectModel(WorldModel worldModel, int imageWidth, int imageHeight) {
		this.worldModel = worldModel;
		this.imageWidth = imageWidth;
		this.imageHeight = imageHeight;
	}

	void initTransfomations() {
		this.modelM.identity();
		this.modelM.identity();
		this.lookatM.identity();
		this.projectionM.identity();
		this.viewportM.identity();
	}

	void setModelM(Matrix4f modelM) {
		this.modelM = modelM;
	}

	void setLookatM(Matrix4f lookatM) {
		this.lookatM = lookatM;
	}

	void setProjectionM(Matrix4f projectionM) {
		this.projectionM = projectionM;
	}

	void setViewportM(Matrix4f viewportM) {
		this.viewportM = viewportM;
	}

	public Vector3f getBoundingBoxDimensions() {
		return boundingBoxDimensions;
	}

	public Vector3f getBoundingBoxCenter() {
		return boundingBoxCenter;
	}

	public boolean load(String fileName) {
		OBJLoader objLoader = new OBJLoader();
		try {
			objLoader.loadOBJ(fileName);
			verticesData = objLoader.getVertices();
			faces = objLoader.getFaces();
			boundingBoxDimensions = objLoader.getBoundingBoxDimensions();
			boundingBoxCenter = objLoader.getBoundingBoxCenter();
			textureImageIntBufferWrapper = objLoader.getTextureImageIntBufferWrapper();
			return true;
		} catch (IOException e) {
			// System.err.println("Failed to load the OBJ file.");
			return false;
		}
	}

	public boolean objectHasTexture() {
		return textureImageIntBufferWrapper != null;
	}

	public void render(IntBufferWrapper intBufferWrapper) {
		exercise = worldModel.exercise;
		
	    Vector4f lightPosWorld = new Vector4f(worldModel.lightPositionWorldCoordinates, 1f);
	    Vector4f lightPosEye = new Vector4f();
	    lookatM.transform(lightPosWorld, lightPosEye);
	    lightPositionEyeCoordinates.set(lightPosEye.x, lightPosEye.y, lightPosEye.z);

		if (verticesData != null) {
			for (VertexData vertexData : verticesData) {
				vertexProcessing(intBufferWrapper, vertexData);
			}
			for (TriangleFace face : faces) {
				rasterization(intBufferWrapper, verticesData.get(face.indices[0]), verticesData.get(face.indices[1]),
						verticesData.get(face.indices[2]), face.color);
			}
		}
	}

	private void vertexProcessing(IntBufferWrapper intBufferWrapper, VertexData vertex) {

		// Initialize a 4D vector from the 3D vertex point
		Vector4f t = new Vector4f(vertex.pointObjectCoordinates, 1f);

		// Transform only model transformation
		modelM.transform(t);
	    lookatM.transform(t);
		vertex.pointEyeCoordinates = new Vector3f(t.x, t.y, t.z);

	    projectionM.transform(t);
	    if (t.w != 0f) {
	        t.x /= t.w;
	        t.y /= t.w;
	        t.z /= t.w;
	        t.w = 1f;
	    }
	    viewportM.transform(t);
		vertex.pointWindowCoordinates = new Vector3f(t.x, t.y, t.z);

		// transformation normal from object coordinates to eye coordinates v->normal
		///////////////////////////////////////////////////////////////////////////////////
		transformNormalFromObjectCoordToEyeCoordAndDrawIt(intBufferWrapper, vertex);
		
		if (worldModel.displayType == DisplayTypeEnum.LIGHTING_GOURARD) {
		    vertex.lightingIntensity0to1 = lightingEquation(
		        vertex.pointEyeCoordinates,
		        vertex.normalEyeCoordinates,
		        lightPositionEyeCoordinates,
		        worldModel.lighting_Diffuse,
		        worldModel.lighting_Specular,
		        worldModel.lighting_Ambient,
		        worldModel.lighting_sHininess
		    );
		}
		

	}

	private void transformNormalFromObjectCoordToEyeCoordAndDrawIt(IntBufferWrapper intBufferWrapper,
			VertexData vertex) {
		// transformation normal from object coordinates to eye coordinates v->normal
		///////////////////////////////////////////////////////////////////////////////////
		// --> v->NormalEyeCoordinates
		Matrix4f modelviewM = new Matrix4f(lookatM).mul(modelM);
		Matrix3f modelviewM3x3 = new Matrix3f();
		modelviewM.get3x3(modelviewM3x3);
		vertex.normalEyeCoordinates = new Vector3f();
		modelviewM3x3.transform(vertex.normalObjectCoordinates, vertex.normalEyeCoordinates);
		if (worldModel.displayNormals) {
			// drawing normals
			Vector3f t1 = new Vector3f(vertex.normalEyeCoordinates);
			Vector4f point_plusNormal_eyeCoordinates = new Vector4f(t1.mul(0.1f).add(vertex.pointEyeCoordinates), 1);
			Vector4f t2 = new Vector4f(point_plusNormal_eyeCoordinates);
			// modelviewM.transform(t2);
			projectionM.transform(t2);
			if (t2.w != 0) {
				t2.mul(1 / t2.w);
			} else {
				System.err.println("Division by w == 0 in vertexProcessing normal transformation");
			}
			viewportM.transform(t2);
			Vector3f point_plusNormal_screen = new Vector3f(t2.x, t2.y, t2.z);
			drawLineDDA(intBufferWrapper, vertex.pointWindowCoordinates, point_plusNormal_screen, 0, 0, 1f);
		}

	}

	private void rasterization(IntBufferWrapper intBufferWrapper, VertexData vertex1, VertexData vertex2,
			VertexData vertex3, Vector3f faceColor) {

		Vector3f faceNormal = new Vector3f(vertex2.pointEyeCoordinates).sub(vertex1.pointEyeCoordinates)
				.cross(new Vector3f(vertex3.pointEyeCoordinates).sub(vertex1.pointEyeCoordinates)).normalize();

		if (worldModel.displayType == DisplayTypeEnum.FACE_EDGES) {
			drawLineDDA(intBufferWrapper, vertex1.pointWindowCoordinates, vertex2.pointWindowCoordinates, 1f, 1f, 1f);
			drawLineDDA(intBufferWrapper, vertex1.pointWindowCoordinates, vertex3.pointWindowCoordinates, 1f, 1f, 1f);
			drawLineDDA(intBufferWrapper, vertex2.pointWindowCoordinates, vertex3.pointWindowCoordinates, 1f, 1f, 1f);

		} else {
			Vector3f p1 = vertex1.pointWindowCoordinates;
			Vector3f p2 = vertex2.pointWindowCoordinates;
			Vector3f p3 = vertex3.pointWindowCoordinates;

			Vector4i boundingBox = calcBoundingBox(p1, p2, p3,imageWidth,
					imageHeight);
			BarycentricCoordinates bc = new BarycentricCoordinates(p1, p2, p3);

			float faceIntensity = 0;
			if (worldModel.displayType == DisplayTypeEnum.LIGHTING_FLAT) {
			    faceIntensity = lightingEquation(
			        vertex1.pointEyeCoordinates,  // using any vertex of the face
			        faceNormal,
			        lightPositionEyeCoordinates,
			        worldModel.lighting_Diffuse,
			        worldModel.lighting_Specular,
			        worldModel.lighting_Ambient,
			        worldModel.lighting_sHininess
			    );
			}

			for (int y = boundingBox.z; y <= boundingBox.w; y++) {
				for (int x = boundingBox.x; x <= boundingBox.y; x++) {
					bc.calcCoordinatesForPoint(x, y);
					if (bc.isPointInside()) {
						FragmentData fragmentData = new FragmentData();
						if (worldModel.displayType == DisplayTypeEnum.FACE_COLOR) {
							fragmentData.pixelColor = new Vector3f(faceColor);
						} else if (worldModel.displayType == DisplayTypeEnum.INTERPOlATED_VERTEX_COLOR) {
							Vector3f interpolateColor = bc.interpolate(vertex1.color, vertex2.color, vertex3.color);
							fragmentData.pixelColor = new Vector3f(interpolateColor);
						} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_FLAT) {
						    fragmentData.pixelIntensity0to1 = faceIntensity;
						} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_GOURARD) {
						    float interpolatedIntensity = bc.interpolate(
						            vertex1.lightingIntensity0to1,
						            vertex2.lightingIntensity0to1,
						            vertex3.lightingIntensity0to1
						        );
						        fragmentData.pixelIntensity0to1 = interpolatedIntensity;
						} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_PHONG) {
							fragmentData.pointEyeCoordinates = bc.interpolate(
									vertex1.pointEyeCoordinates,
									vertex2.pointEyeCoordinates,
									vertex3.pointEyeCoordinates
							    );

							    fragmentData.normalEyeCoordinates = bc.interpolate(
						    		vertex1.normalEyeCoordinates,
						    		vertex2.normalEyeCoordinates,
						    		vertex3.normalEyeCoordinates
							    ).normalize();
						} else if (worldModel.displayType == DisplayTypeEnum.TEXTURE) {
							fragmentData.textureCoordinates = bc.interpolate(
						            vertex1.textureCoordinates,
						            vertex2.textureCoordinates,
						            vertex3.textureCoordinates);
						} else if (worldModel.displayType == DisplayTypeEnum.TEXTURE_LIGHTING) {
							 fragmentData.textureCoordinates = bc.interpolate(
								        vertex1.textureCoordinates,
								        vertex2.textureCoordinates,
								        vertex3.textureCoordinates);
								        
								    fragmentData.pointEyeCoordinates = bc.interpolate(
								        vertex1.pointEyeCoordinates,
								        vertex2.pointEyeCoordinates,
								        vertex3.pointEyeCoordinates);
								    
								    fragmentData.normalEyeCoordinates = bc.interpolate(
								        vertex1.normalEyeCoordinates,
								        vertex2.normalEyeCoordinates,
								        vertex3.normalEyeCoordinates).normalize();
							
						}
						float z = bc.interpolate(p1.z,p2.z,p3.z);
						if (z < worldModel.zBuffer[y][x]) {
						    worldModel.zBuffer[y][x] = z;
							Vector3f pixelColor = fragmentProcessing(fragmentData);
							intBufferWrapper.setPixel(x, y, pixelColor);
						}
					}
				}
			}
		}

	}

	private Vector3f fragmentProcessing(FragmentData fragmentData) {

		if (worldModel.displayType == DisplayTypeEnum.FACE_COLOR) {
			return fragmentData.pixelColor;
		} else if (worldModel.displayType == DisplayTypeEnum.INTERPOlATED_VERTEX_COLOR) {
			return fragmentData.pixelColor;
		} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_FLAT) {
		    float intensity = fragmentData.pixelIntensity0to1;
		    return new Vector3f(intensity, intensity, intensity);
		} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_GOURARD) {
			float intensity = fragmentData.pixelIntensity0to1;
		    return new Vector3f(intensity, intensity, intensity);
		} else if (worldModel.displayType == DisplayTypeEnum.LIGHTING_PHONG) {
		    Vector3f lightPos = lightPositionEyeCoordinates;
		    Vector3f L = new Vector3f(lightPos)
		            .sub(fragmentData.pointEyeCoordinates).normalize();
		        Vector3f N = new Vector3f(fragmentData.normalEyeCoordinates).normalize();
		        float diff = Math.max(N.dot(L), 0);
		        float ambient = worldModel.lighting_Ambient;
		        float intensity = ambient + worldModel.lighting_Diffuse * diff;
		        return new Vector3f(intensity, intensity, intensity);
		} else if (worldModel.displayType == DisplayTypeEnum.TEXTURE) {
		    int texX = Math.round(fragmentData.textureCoordinates.x * (textureImageIntBufferWrapper.getImageWidth() - 1));
		    int texY = Math.round(fragmentData.textureCoordinates.y * (textureImageIntBufferWrapper.getImageHeight() - 1));
		    return textureImageIntBufferWrapper.getPixel(texX, texY);
		} else if (worldModel.displayType == DisplayTypeEnum.TEXTURE_LIGHTING) {
		    int texX = Math.round(fragmentData.textureCoordinates.x * (textureImageIntBufferWrapper.getImageWidth() - 1));
		    int texY = Math.round(fragmentData.textureCoordinates.y * (textureImageIntBufferWrapper.getImageHeight() - 1));
		    Vector3f textureColor = textureImageIntBufferWrapper.getPixel(texX, texY);
		    Vector3f lightPos = lightPositionEyeCoordinates;
		    Vector3f L = new Vector3f(lightPos).sub(fragmentData.pointEyeCoordinates).normalize();
		    Vector3f N = new Vector3f(fragmentData.normalEyeCoordinates).normalize();
		    float diff = Math.max(N.dot(L), 0);
		    float ambient = worldModel.lighting_Ambient;
		    float intensity = ambient + worldModel.lighting_Diffuse * diff;


		    Vector3f finalColor = new Vector3f(textureColor).mul(intensity);

		    return finalColor;
			
			
		}
		return new Vector3f();

	}

	static void drawLineDDA(IntBufferWrapper intBufferWrapper, Vector3f p1, Vector3f p2, float r, float g, float b) {
		int x1 = Math.round(p1.x);
		int y1 = Math.round(p1.y);
		int x2 = Math.round(p2.x);
		int y2 = Math.round(p2.y);

		int dx = x2 - x1;
		int dy = y2 - y1;

		int steps = Math.max(Math.abs(dx), Math.abs(dy));
		if (steps == 0)
			return;

		float xInc = dx / (float) steps;
		float yInc = dy / (float) steps;

		float x = x1;
		float y = y1;

		for (int i = 0; i <= steps; i++) {
			intBufferWrapper.setPixel(Math.round(x), Math.round(y), new Vector3f(r, g, b));
			x += xInc;
			y += yInc;
		}
	}

	static Vector4i calcBoundingBox(Vector3f p1, Vector3f p2, Vector3f p3, int imageWidth, int imageHeight) {
		int minX, maxX, minY, maxY;
		minX = (int) Math.max(0, Math.min(Math.min(p1.x, p2.x), p3.x));
		maxX = Math.round(Math.min(imageWidth - 1, Math.max(Math.max(p1.x, p2.x), p3.x)));
		minY = (int) Math.max(0, Math.min(Math.min(p1.y, p2.y), p3.y));
		maxY = Math.round(Math.min(imageHeight - 1, Math.max(Math.max(p1.y, p2.y), p3.y)));

		return new Vector4i(minX, maxX, minY, maxY);

	}

	float lightingEquation(Vector3f point, Vector3f PointNormal, Vector3f LightPos, float Kd, float Ks, float Ka,
			float shininess) {

		Vector3f color = lightingEquation(point, PointNormal, LightPos, new Vector3f(Kd), new Vector3f(Ks),
				new Vector3f(Ka), shininess);
		return color.get(0);
	}

	private static Vector3f lightingEquation(Vector3f point, Vector3f PointNormal, Vector3f LightPos,
	        Vector3f Kd, Vector3f Ks, Vector3f Ka, float shininess) {

	    Vector3f N = new Vector3f(PointNormal).normalize();
	    Vector3f L = new Vector3f(LightPos).sub(point).normalize();
	    Vector3f V = new Vector3f(point).negate().normalize();
	    Vector3f R = new Vector3f(N).mul(2.0f * N.dot(L)).sub(L).normalize();

	    float NdotL = Math.max(N.dot(L), 0f);
	    float RdotV = Math.max(R.dot(V), 0f);

	    Vector3f ambient = new Vector3f(Ka);
	    Vector3f diffuse = new Vector3f(Kd).mul(NdotL);
	    Vector3f specular = new Vector3f(Ks).mul((float) Math.pow(RdotV, shininess));

	    Vector3f color = new Vector3f();
	    color.add(ambient).add(diffuse).add(specular);
	    color.x = Math.min(Math.max(color.x, 0f), 1f);
	    color.y = Math.min(Math.max(color.y, 0f), 1f);
	    color.z = Math.min(Math.max(color.z, 0f), 1f);

	    return color;
	}

}
