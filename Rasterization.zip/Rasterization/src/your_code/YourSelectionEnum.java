package your_code;

public enum YourSelectionEnum {
	OPTION_1, 
	OPTION_2,
	OPTION_3
};
