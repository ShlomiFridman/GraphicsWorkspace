package app_interface;

public enum ProjectionTypeEnum {
	ORTHOGRAPHIC, PERSPECTIVE
};

