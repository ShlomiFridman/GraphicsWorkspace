// student 1 - Omer Goldstein - 205906258
// student 2 - Shlomi Fridman - 318187002

package your_code;

import java.nio.IntBuffer;
import java.util.Random;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import app_interface.DisplayTypeEnum;
import app_interface.ExerciseEnum;
import app_interface.IntBufferWrapper;
import app_interface.ProjectionTypeEnum;

public class WorldModel {

	// type of rendering
	public ProjectionTypeEnum projectionType;
	public DisplayTypeEnum displayType;
	public boolean displayNormals;
	public YourSelectionEnum yourSelection;
	
	// camera location parameters
	public Vector3f cameraPos = new Vector3f();
	public Vector3f cameraLookAtCenter = new Vector3f();
	public Vector3f cameraUp = new Vector3f();
	public float horizontalFOV;

	// transformation parameters
	public float modelScale;

	// lighting parameters
	public float lighting_Diffuse;
	public float lighting_Specular;
	public float lighting_Ambient;
	public float lighting_sHininess;
	public Vector3f lightPositionWorldCoordinates = new Vector3f();
	
	public ExerciseEnum exercise;

	private int imageWidth;
	private int imageHeight;

	private ObjectModel object1;
	
	float zBuffer[][];
	
	private float currentX = 0f;
	private float currentY = 0f;	
	
	private int counter = 0;
	
	ErrorLogger errorLogger;
	
	public WorldModel(int imageWidth, int imageHeight, ErrorLogger errorLogger) {
		this.imageWidth  = imageWidth;
		this.imageHeight = imageHeight;
		this.zBuffer = new float[imageWidth][imageHeight];
		this.errorLogger = errorLogger;
	}


	public boolean load(String fileName) {
		object1 = new ObjectModel(this, imageWidth, imageHeight);
		return object1.load(fileName);
	}
	
	public boolean modelHasTexture() {
		return object1.objectHasTexture();
	}
	
	
	public void render(IntBufferWrapper intBufferWrapper) {
		counter+=1;
		intBufferWrapper.imageClear();
		clearZbuffer();
		object1.initTransfomations();

		if (exercise.ordinal() == ExerciseEnum.EX_3_1_Object_transformation___translation.ordinal()) {
		    float dx = -2 + (float)(Math.random() * 4); // -2 to 2
		    float dy = -2 + (float)(Math.random() * 4); // -2 to 2
		    currentX += dx;
		    currentY += dy;
		    Matrix4f translationMatrix = new Matrix4f().translate(currentX, currentY, 0f);
		    object1.setModelM(translationMatrix);


		}
	
		if (exercise.ordinal() == ExerciseEnum.EX_3_2_Object_transformation___scale.ordinal()) {
		    int period = 40;
		    float centerX = 300f;
		    float centerY = 300f;
		    float minScale = 0.8f;
		    float maxScale = 1.1f;
		    int frameInCycle = counter % period;
		    float scale;
		    if (frameInCycle < period / 2) {
		        scale = minScale + (maxScale - minScale) * (frameInCycle / (float)(period / 2));
		    } else 
		        scale = maxScale - (maxScale - minScale) * ((frameInCycle - period / 2) / (float)(period / 2));
		    Matrix4f scaleM = new Matrix4f()
		    	    .translate(centerX, centerY, 0)
		    	    .scale(scale)
		    	    .translate(-centerX, -centerY, 0);
		    object1.setModelM(scaleM);
		}

		if (exercise.ordinal() == ExerciseEnum.EX_3_3_Object_transformation___4_objects.ordinal()) {
			float[][] positions = {
			        {0f, 0f},
			        {600f, 0f},
			        {0f, 600f},
			        {600f, 600f}
			    };

			    for (int i = 0; i < positions.length; i++) {
			        float x = positions[i][0];
			        float y = positions[i][1];

			        Matrix4f scaleM = new Matrix4f()
			            .translate(x, y, 0)
			            .scale(0.5f)
			            .translate(-x, -y, 0);

			        object1.setModelM(scaleM);

			        if (i < positions.length - 1) {
			            object1.render(intBufferWrapper);
			        }
			    }
			    
		    
		}


			if(projectionType==ProjectionTypeEnum.ORTHOGRAPHIC) {
				Matrix4f orthoProjection = new Matrix4f().ortho(-1.5f, 1.5f, -1.5f, 1.5f, 1f, -1f);
				object1.setProjectionM(orthoProjection);
			}
			Matrix4f viewportMatrix = YoursUtilities.createViewportMatrix(0, 0, imageWidth, imageHeight);
			object1.setViewportM(viewportMatrix);
			
			Matrix4f lookAtMatrix = new Matrix4f().lookAt(cameraPos, cameraLookAtCenter, cameraUp);
			object1.setLookatM(lookAtMatrix);


			
			if(projectionType==ProjectionTypeEnum.PERSPECTIVE) {
				Matrix4f projectionM = new Matrix4f().perspective((float) Math.toRadians(30), 1, 1, 100);
				object1.setProjectionM(projectionM);

			}
			
		
		object1.render(intBufferWrapper);
	}
	
	private void clearZbuffer() {
		for(int i=0; i<imageHeight; i++)
			for(int j=0; j<imageWidth; j++)
				zBuffer[i][j] = 1;
	}	
}
